# Kaggle RAG Solution

## Overview

This repository contains my solution for a Retrieval-Augmented Generation (RAG) competition.

The approach intentionally uses a lightweight and fully reproducible retrieval pipeline based on TF‑IDF vectorization and cosine similarity. No external APIs, internet access, vector databases, or large language models are required during inference.

## Solution

### Retrieval

Documents are constructed by concatenating:

- `title`
- `text`

from `websites.csv`.

A TF‑IDF index is built using:

- unigram and bigram features (`ngram_range=(1, 2)`)
- `max_df=0.9`
- `min_df=2`

For each query:

1. The query is transformed into TF‑IDF space.
2. Cosine similarity is computed against all documents.
3. Top‑3 most relevant documents are retrieved.

### Answer Construction

The final answer is created by:

1. Taking the top retrieved documents.
2. Concatenating the first two retrieved chunks.
3. Truncating the result to 400 characters.

## Repository Structure

```text
.
├── README.md
├── requirements.txt
├── inference.py
└── submission_example.csv
```

## Expected Dataset Structure

```text
rag-dataset/
├── websites.csv
├── questions.csv
└── sample_submission.csv
```

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python inference.py --data-dir rag-dataset
```

The script generates:

```text
submission.csv
```
