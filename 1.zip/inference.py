import argparse
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from tqdm import tqdm


def load_data(data_dir):
    websites = pd.read_csv(f"{data_dir}/websites.csv")
    questions = pd.read_csv(f"{data_dir}/questions.csv")
    return websites, questions


def build_corpus(websites):
    return (
        websites["title"].fillna("").astype(str)
        + " "
        + websites["text"].fillna("").astype(str)
    ).tolist()


def retrieve(query, vectorizer, doc_embeddings, texts, k=3):
    q_vec = vectorizer.transform([query])
    sims = cosine_similarity(q_vec, doc_embeddings)[0]
    top_idx = np.argsort(sims)[-k:][::-1]
    return [texts[i] for i in top_idx]


def build_answer(chunks):
    text = " ".join(chunks[:2])
    return text[:400]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="rag-dataset")
    args = parser.parse_args()

    websites, questions = load_data(args.data_dir)
    texts = build_corpus(websites)

    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        max_df=0.9,
        min_df=2,
    )

    doc_embeddings = vectorizer.fit_transform(texts)

    answers = []

    for _, row in tqdm(questions.iterrows(), total=len(questions)):
        context = retrieve(
            row["query"],
            vectorizer,
            doc_embeddings,
            texts,
            k=3,
        )

        answers.append(
            {
                "q_id": row["q_id"],
                "answer_new": build_answer(context),
            }
        )

    pd.DataFrame(answers).to_csv("submission.csv", index=False)
    print("submission.csv created")


if __name__ == "__main__":
    main()
